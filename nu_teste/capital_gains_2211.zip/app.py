from src.infra.cli import run

"""
Application Entrypoint
"""
if __name__ == "__main__":
    print(f"# Capital Gains #")
    run()
