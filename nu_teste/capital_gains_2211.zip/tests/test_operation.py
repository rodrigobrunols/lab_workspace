from unittest import TestCase

from src.domain.models.money import Money
from src.domain.models.operation import Operation, OperationType


class TestOperation(TestCase):
    def test_is_buy(self):
        test_operation = Operation(
            operation=OperationType.BUY,
            quantity=1,
            unit_cost=Money.zero()
        )
        self.assertTrue(test_operation.is_buy)

    def test_is_sell(self):
        test_operation = Operation(
            operation=OperationType.SELL,
            quantity=1,
            unit_cost=Money.zero()
        )
        self.assertTrue(test_operation.is_sell)
