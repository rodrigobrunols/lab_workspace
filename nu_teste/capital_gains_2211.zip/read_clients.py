import json


def load_file():
    with open("/Users/rodrigobruno/Downloads/clients-ditec-prod.json", "r") as f:
        for raw_line in f:
            print(raw_line.strip())


# case = json.load(f)
# client_ids = [client["clientId"] for client in case]

if __name__ == '__main__':
    load_file()
