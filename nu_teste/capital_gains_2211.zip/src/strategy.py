from abc import ABC, abstractmethod
from collections import deque

from src.domain.models.operation import Operation, OperationType
from src.domain.position.state import PositionState


class CostStrategy(ABC):

    @abstractmethod
    def handle_buy(self, operation: Operation, state: PositionState):
        pass

    @abstractmethod
    def handle_sell(self, operation: Operation, state: PositionState):
        pass


class FIFOCostStrategy(CostStrategy):

    def __init__(self):
        self.lots = deque()

    def handle_buy(self, operation: Operation, state: PositionState):
        self.lots.append([operation.quantity, operation.unit_cost])

    def handle_sell(self, state, op):
        remaining = op.quantity
        profit = 0

        while remaining > 0:
            qty, cost = self.lots[0]

            if qty <= remaining:
                profit += (op.unit_cost - cost) * qty
                remaining -= qty
                self.lots.popleft()
            else:
                profit += (op.unit_cost - cost) * remaining
                self.lots[0][0] -= remaining
                remaining = 0

        return profit


class LIFOCostStrategy(CostStrategy):

    def __init__(self):
        self.lots = deque()

    def handle_buy(self, operation: Operation, state: PositionState):
        if operation.operation != OperationType.BUY:
            raise ValueError("Operation type must be OperationType.BUY")

        self.lots.append([operation.quantity, operation.unit_cost])

    def handle_sell(self, state, op):
        if op.operation != OperationType.SELL:
            raise ValueError("Operation type must be OperationType.SELL")

        remaining = op.quantity
        profit = 0

        while remaining > 0:
            qty, cost = self.lots[-1]

            if qty <= remaining:
                profit += (op.unit_cost - cost) * qty
                remaining -= qty
                self.lots.pop()
            else:
                profit += (op.unit_cost - cost) * remaining
                self.lots[-1][0] = qty - remaining
                remaining = 0

        return profit
