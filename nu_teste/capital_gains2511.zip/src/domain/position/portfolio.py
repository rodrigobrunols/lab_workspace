from src.domain.position.state import PositionState


class Portfolio:

    def __init__(self):
        self.wallet = {}

    def get_ticker_state(self, ticker: str):
        keyword = ticker.upper()
        if keyword not in self.wallet:
            self.wallet[keyword] = PositionState()

        return self.wallet[keyword]
