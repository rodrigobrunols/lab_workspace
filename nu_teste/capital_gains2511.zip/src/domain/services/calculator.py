from typing import List

from src.domain.exceptions.exceptions import DomainError, CalculatorLockedError
from src.domain.models.operation import Operation
from src.domain.models.result import OperationResult
from src.domain.position.portfolio import Portfolio
from src.domain.rules.base import Rule
from src.domain.rules.buy_rule import BuyRule
from src.domain.rules.sell_rule import SellRule
from src.domain.rules.validators import validate


class CapitalGainsCalculator:
    """
    Service that applies the set of rules at current state
    """

    def __init__(self, state: Portfolio = None, rules: List[Rule] = None):
        self.state = state or Portfolio()
        self.rules = rules or [BuyRule(), SellRule()]
        self.errors = 0
        self.locked = False

    def process(self, op: Operation) -> OperationResult:
        try:
            validate(op, self.state.get_ticker_state(op.ticker))

            for rule in self.rules:
                if rule.applies(op):
                    return rule.execute(self.state.get_ticker_state(op.ticker), op)

        except DomainError as e:
            self.errors += 1
            # print(f">>> errors count={self.errors}")

            if self.errors >= 3:
                # print(f">>> locked calculator")
                self.locked = True
                raise CalculatorLockedError("Locked due to too many errors")

            raise e
