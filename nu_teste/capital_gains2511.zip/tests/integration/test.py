import json
from unittest import TestCase

from src.domain.exceptions.exceptions import DomainError
from src.domain.models.operation import Operation
from src.domain.services.calculator import CapitalGainsCalculator
from src.infra.jsonio import parse_operations, DecimalEncoder


class TestFile(TestCase):

    def test_file(self):
        path = "tests.txt"
        with open(path, "r") as file:
            for raw_line in file:
                line = raw_line.strip()
                if not line:
                    break
                ops_data = parse_operations(line)
                calc = CapitalGainsCalculator()  # Creates a new calculator for each line to make each line independent
                results = []
                for d in ops_data:
                    try:
                        op = Operation(**d)
                        res = calc.process(op)
                        # Convert Money → float BEFORE passing to json.dumps
                        results.append({
                            "tax": float(res.tax.value)
                        })
                    except DomainError as e:
                        results.append({
                            "error": e.message
                        })

                print(json.dumps(results, cls=DecimalEncoder))
