import unittest
from unittest import TestCase

from src.domain.exceptions.exceptions import DomainError, CalculatorLockedError
from src.domain.services.calculator import CapitalGainsCalculator
from src.domain.models.money import Money
from src.domain.models.operation import Operation, OperationType


class TestCalculator(unittest.TestCase):

    def setUp(self):
        self.calc = CapitalGainsCalculator()

    def test_calculator_processes_sequence(self):
        ops = [
            Operation(OperationType.BUY.value, Money("10"), 100),
            Operation(OperationType.SELL.value, Money("15"), 50),
            Operation(OperationType.SELL.value, Money("15"), 50),
        ]

        taxes = [self.calc.process(op).tax for op in ops]

        self.assertEqual(taxes, [Money("0"), Money("0"), Money("0")])

    def test_process_raise_domain_error(self):
        ops = [
            Operation(OperationType.SELL.value, Money("15"), 51),
        ]

        with self.assertRaises(DomainError) as ctx:
            result = [self.calc.process(op).tax for op in ops]

        self.assertEqual(self.calc.errors, 1)
        self.assertFalse(self.calc.locked)

    def test_lock_calculator_after_3_errors(self):
        ops = [
            Operation(OperationType.SELL.value, Money("15"), 51),
            Operation(OperationType.SELL.value, Money("15"), 51),
            Operation(OperationType.SELL.value, Money("15"), 51),
        ]

        for idx, op in enumerate(ops):
            if idx < 2:
                # First two should raise DomainError but not lock
                with self.assertRaises(DomainError):
                    self.calc.process(op)
                self.assertFalse(self.calc.locked)
            elif idx >= 2:
                # The 3rd error should lock the calculator
                with self.assertRaises(CalculatorLockedError):
                    self.calc.process(op)
                self.assertTrue(self.calc.locked)

        self.assertEqual(self.calc.errors, 3)
