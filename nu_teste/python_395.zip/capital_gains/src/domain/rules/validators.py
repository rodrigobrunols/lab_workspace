from src.domain.exceptions.exceptions import ValidationError, InvalidOperationError
from src.domain.models.operation import Operation, OperationType
from src.domain.position.state import PositionState


def validate_positive_quantity(op: Operation):
    if op.quantity <= 0:
        raise ValidationError("Quantity must be positive")


def validate_positive_cost(op: Operation):
    if op.unit_cost <= 0:
        raise ValidationError("Unit cost must be positive")


def validate_operation_type(op: Operation):
    if op.operation not in [OperationType.SELL, OperationType.BUY]:
        raise InvalidOperationError(f"Invalid operation type: {op.operation}")


def validate(op: Operation, portfolio: PositionState):
    validators = [
        validate_positive_quantity,
        validate_positive_cost,
        validate_operation_type,
    ]

    for rule in validators:
        rule(op)
