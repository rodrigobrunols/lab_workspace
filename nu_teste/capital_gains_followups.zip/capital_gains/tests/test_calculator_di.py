from unittest import TestCase
from unittest.mock import MagicMock

from src.domain.models.money import Money
from src.domain.models.operation import Operation, OperationType
from src.domain.services.calculator import CapitalGainsCalculator


class TestCapitalGainsCalculatorWithDI(TestCase):

    def test_calculator_uses_injected_rules(self):
        mock_rule = MagicMock()
        mock_rule.applies.return_value = True

        calc = CapitalGainsCalculator(rules=[mock_rule])

        op = Operation(quantity=1,
                       operation=OperationType.BUY,
                       unit_cost=Money("1"),
                       )

        result = calc.process(op)
        mock_rule.applies.assert_called_once_with(op)
        mock_rule.execute.assert_called_once()
