from unittest import TestCase

from src.domain.exceptions.exceptions import ValidationError
from src.domain.models.money import Money
from src.domain.models.operation import Operation, OperationType
from src.domain.position.state import PositionState
from src.domain.rules.validators import validate_cannot_sell_more_then_current_state


class Test(TestCase):
    def test_validate_cannot_sell_more_then_current_state(self):
        test_op = Operation(operation=OperationType.SELL,
                            quantity=1,
                            unit_cost=Money.zero())

        test_state = PositionState()

        with self.assertRaises(ValidationError) as ctx:
            validate_cannot_sell_more_then_current_state(op=test_op, state=test_state)

        self.assertIn(str(ctx.exception), "Cannot sell more then current position")
