from src.domain.strategy.strategy import *
from src.domain.models.money import Money
from src.domain.models.operation import Operation
from src.domain.models.result import OperationResult
from src.domain.position.state import PositionState
from src.domain.rules.base import Rule


class BuyRule(Rule):
    """
    Implement rules for BUY Operation described in Capital Gain spec
    """

    def __init__(self, strategy: CostStrategy = None):
        self.strategy = strategy or AverageCostStrategy()

    def applies(self, operation: Operation) -> bool:
        return operation.is_buy

    def execute(self, state: PositionState, operation: Operation) -> OperationResult:
        self.strategy.handle_buy(state, operation)
        return OperationResult.zero()
