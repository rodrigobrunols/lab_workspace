from typing import List

from domain.strategy.strategy import CostStrategy, AverageCostStrategy
from src.domain.exceptions.exceptions import CapitalGainsError
from src.domain.models.operation import Operation
from src.domain.models.result import OperationResult
from src.domain.position.state import PositionState
from src.domain.rules.base import Rule
from src.domain.rules.buy_rule import BuyRule
from src.domain.rules.sell_rule import SellRule
from src.domain.rules.validators import validate


class CapitalGainsCalculator:
    """
    Service that applies the set of rules at current state
    """

    def __init__(self, strategy: CostStrategy, rules: List[Rule] = None, state: PositionState = None):
        self.strategy = strategy or AverageCostStrategy()
        self.state = state or PositionState()
        self.rules = rules or [BuyRule(strategy), SellRule(strategy)]

    def process(self, op: Operation) -> OperationResult:
        validate(op, self.state)

        for rule in self.rules:
            if rule.applies(op):
                return rule.execute(self.state, op)

        raise CapitalGainsError(f"No rule found for operation: {op.operation}")
