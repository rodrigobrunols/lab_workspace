from abc import ABC, abstractmethod

from src.domain.models.operation import Operation
from src.domain.position.state import PositionState


class CostStrategy(ABC):

    @abstractmethod
    def handle_buy(self, state: PositionState, operation: Operation):
        pass

    @abstractmethod
    def handle_sell(self, state: PositionState, operation: Operation):
        pass


class AverageCostStrategy(CostStrategy):
    def handle_buy(self, state: PositionState, operation: Operation):
        operation_total_cost = operation.unit_cost * operation.quantity

        state.total_quantity += operation.quantity
        state.total_cost += operation_total_cost

    def handle_sell(self, state: PositionState, operation: Operation):
        average_cost = state.average_cost
        profit = (operation.unit_cost - average_cost) * operation.quantity

        # ---------------------------------------------------
        # Update position after the sale
        # ---------------------------------------------------
        state.total_quantity -= operation.quantity
        state.total_cost = state.total_quantity * average_cost
        return profit


class FIFOCostStrategy:
    pass


class LIFOCostStrategy:
    pass


STRATEGIES = {
    "pmp": AverageCostStrategy,
    "fifo": FIFOCostStrategy,
    "lifo": LIFOCostStrategy,
}
