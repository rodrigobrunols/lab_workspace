class CapitalGainsError(Exception):
    """Base class for domain exceptions."""
    pass


class InvalidOperationError(CapitalGainsError):
    """Raised when the operation is unrecognized or unsupported."""
    pass


class ValidationError(CapitalGainsError):
    """Raised when input data is invalid."""
    pass
