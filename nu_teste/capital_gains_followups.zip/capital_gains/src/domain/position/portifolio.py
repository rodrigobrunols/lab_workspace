from domain.position.state import PositionState


class PortfolioState:
    """
    Keeps current position map os ticker -> state for system portfolio: {ticker : PositionState}
    """

    def __init__(self):
        self.positions = {}

    def get_position(self, ticker: str):
        """
        Retrieve the current state for the ticker

        :param ticker: Ticker for a stock
        :return: PositionState: state for the ticker
        """
        key = ticker.upper()
        if key not in self.positions:
            self.positions[key] = PositionState()
        return self.positions[key]
