from unittest import TestCase

from src.domain.exceptions.exceptions import DomainError
from src.domain.models.money import Money
from src.domain.models.operation import Operation, OperationType
from src.domain.position.state import PositionState
from src.domain.rules.validators import validate


class TestValidators(TestCase):

    def test_validate_cannot_sell_more_then_current_state(self):
        test_operation = Operation(operation=OperationType.SELL,
                                   quantity=1,
                                   unit_cost=Money("1"))

        test_state = PositionState()

        with self.assertRaises(DomainError) as ctx:
            validate(test_operation, test_state)

        self.assertIn(str(ctx.exception), "Cannot sell more than current quantity")
