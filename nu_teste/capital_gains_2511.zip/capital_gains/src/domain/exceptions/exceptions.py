class CapitalGainsError(Exception):
    """Base class for domain exceptions."""

    def __init__(self, message=None):
        self.message = message
        super().__init__()


class InvalidOperationError(CapitalGainsError):
    """Raised when the operation is unrecognized or unsupported."""
    pass


class ValidationError(CapitalGainsError):
    """Raised when input data is invalid."""
    pass


class DomainError(CapitalGainsError):
    """Raised when a domain error happens"""
    pass


class CalculatorBlockedError(CapitalGainsError):
    """Raised when the  CapitalGainsCalculator is blocked due to too many errors"""
    pass
